import React from 'react';
import Button from './Button';

const CampusFranceSection: React.FC = () => {
    const bgPattern = `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%230D1B2A' fill-opacity='0.05' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`;

  return (
    <section
        id="campus-france"
        className="bg-beige-clair py-20"
        style={{ backgroundImage: bgPattern }}
    >
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-poppins font-bold mb-4">Campus France Madagascar</h2>
        <p className="font-inter text-lg max-w-3xl mx-auto text-gray-700 mb-8 leading-relaxed">
          L'agence pour la promotion de l'enseignement supérieur, l'accueil et la mobilité internationale. Préparez votre projet d'études en France avec notre accompagnement.
        </p>
        <Button>En savoir plus</Button>
      </div>
    </section>
  );
};

export default CampusFranceSection;