import React from 'react';
import Button from './Button';

// --- Icon Components for Featured Items ---
const BookIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-vif" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
  </svg>
);

const FilmIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-vif" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const MusicIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-vif" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z" />
  </svg>
);

const iconMap = {
  Livre: <BookIcon />,
  Film: <FilmIcon />,
  Musique: <MusicIcon />,
};

const featuredItems = [
    {
      type: 'Livre' as keyof typeof iconMap,
      title: 'Petit Pays',
      description: 'Par Gaël Faye. Un roman poignant sur l\'enfance et la guerre.',
    },
    {
      type: 'Film' as keyof typeof iconMap,
      title: 'Portrait de la jeune fille en feu',
      description: 'De Céline Sciamma. Une histoire d\'amour inoubliable.',
    },
    {
      type: 'Musique' as keyof typeof iconMap,
      title: 'Brol',
      description: 'Par Angèle. La pop francophone réinventée.',
    },
];

const MediathequeSection: React.FC = () => {
  return (
    <section id="mediatheque" className="bg-beige-clair py-20 md:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="container mx-auto">
        <div className="relative flex flex-col md:flex-row items-center justify-center max-w-6xl mx-auto">
          <div className="w-full md:w-1/2 lg:w-2/5 relative h-80 md:h-96 rounded-xl shadow-2xl overflow-hidden z-0 md:mr-[-10%]">
            <img src="https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=1200&auto=format&fit=crop" alt="Médiathèque" className="w-full h-full object-cover" loading="lazy"/>
          </div>
          <div className="w-full md:w-1/2 lg:w-3/5 bg-white p-8 md:p-12 lg:p-16 rounded-xl shadow-2xl z-10 mt-[-4rem] md:mt-0">
            <h2 className="text-3xl md:text-4xl font-poppins font-bold mb-4">Médiathèque</h2>
            <p className="font-inter text-lg text-gray-700 mb-8 leading-relaxed">
              Découvrez un espace riche de savoirs et de cultures. Notre médiathèque vous ouvre ses portes avec des milliers de documents, livres, films et musiques. Un lieu pour tous les âges et toutes les passions.
            </p>
            <Button>Voir les horaires</Button>
            
            <div className="mt-12 pt-8 border-t border-gray-200">
                <h3 className="font-poppins font-semibold text-xl text-blue-nuit mb-6">À découvrir dans nos rayons</h3>
                <div className="space-y-6">
                    {featuredItems.map((item, index) => (
                        <div key={index} className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-8 h-8 bg-red-vif/10 rounded-full flex items-center justify-center">
                                {iconMap[item.type]}
                            </div>
                            <div>
                                <h4 className="font-poppins font-medium text-blue-nuit">{item.title}</h4>
                                <p className="font-inter text-gray-600 text-sm">{item.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default MediathequeSection;
