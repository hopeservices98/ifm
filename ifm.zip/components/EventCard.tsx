import React from 'react';

interface EventCardProps {
  image: string;
  title: string;
  date: string;
  category: string;
  location?: string;
  description?: string;
}

const EventCard: React.FC<EventCardProps> = ({ image, title, date, category, location, description }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 h-full">
      <div className="relative">
        <img src={image} alt={title} className="w-full h-48 object-cover" loading="lazy" />
        <span className="absolute top-3 right-3 bg-red-vif text-white text-xs font-poppins font-medium px-3 py-1 rounded-full shadow-sm">{category}</span>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="font-poppins font-bold text-xl mb-2 text-blue-nuit">{title}</h3>
        <p className="font-inter text-base text-gray-500 mb-2">{date}</p>
        {location && <p className="font-inter text-sm text-gray-400 mb-3">📍 {location}</p>}
        {description && <p className="font-inter text-sm text-gray-600 mb-4 line-clamp-2">{description}</p>}
        <div className="mt-auto pt-4 border-t border-gray-100">
           <a href="#" className="group font-poppins font-medium text-red-vif hover:text-red-vif-hover transition-colors inline-flex items-center">
            Réserver <span className="transform transition-transform duration-300 group-hover:translate-x-2 ml-2">&rarr;</span>
           </a>
        </div>
      </div>
    </div>
  );
};

export default EventCard;