import React from 'react';

interface SocialIconProps {
  href: string;
  children: React.ReactNode;
}

const SocialIcon = ({ href, children }: SocialIconProps) => (
  <a 
    href={href} 
    target="_blank" 
    rel="noopener noreferrer" 
    className="group relative w-10 h-10 flex items-center justify-center rounded-full transition-colors duration-300"
  >
    <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 rounded-full transition-all duration-300 transform scale-75 group-hover:scale-100"></div>
    <div className="relative text-white group-hover:text-red-vif transition-colors duration-300">
      {children}
    </div>
  </a>
);

const FacebookIcon = () => (
  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
  </svg>
);

const InstagramIcon = () => (
    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.012-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.048-1.024-.06-1.378-.06-3.808s.012-2.784.06-3.808c.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 016.08 2.525c.636-.247 1.363-.416 2.427-.465C9.53 2.013 9.884 2 12.315 2zM12 7a5 5 0 100 10 5 5 0 000-10zm0 8a3 3 0 110-6 3 3 0 010 6zm5.75-9.25a1.25 1.25 0 100-2.5 1.25 1.25 0 000 2.5z" clipRule="evenodd" />
    </svg>
);

const YoutubeIcon = () => (
    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path fillRule="evenodd" d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.78 22 12 22 12s0 3.22-.42 4.814c-.23.861-.907 1.538-1.768 1.768C18.218 19 12 19 12 19s-6.218 0-7.812-.42c-.861-.23-1.538-.907-1.768-1.768C2.002 15.22 2 12 2 12s0-3.22.42-4.814c.23.861.907-1.538 1.768-1.768C5.782 5 12 5 12 5s6.218 0 7.812.418zM9.57 15.57l6.5-3.57-6.5-3.57v7.14z" clipRule="evenodd" />
    </svg>
);

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-blue-nuit text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <h3 className="font-poppins font-bold text-lg mb-4">Institut Français de Madagascar</h3>
            <p className="font-inter mb-2">14 Av. de l'Indépendance, Analakely</p>
            <p className="font-inter mb-2">Antananarivo, Madagascar</p>
            <p className="font-inter mb-2">Téléphone: +261 20 22 236 47</p>
            <p className="font-inter">Email: contact@ifmadagascar.org</p>
          </div>
          <div>
            <h3 className="font-poppins font-bold text-lg mb-4">Retrouvez-nous</h3>
            <div className="w-full h-48 bg-gray-700 rounded-lg overflow-hidden">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3774.729194266399!2d47.52296081489851!3d-18.90001098719045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x21f07e0022f3045d%3A0x7d2a336098f995a9!2sInstitut%20Fran%C3%A7ais%20de%20Madagascar!5e0!3m2!1sen!2sus!4v1678886543210!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
          </div>
          <div>
             <h3 className="font-poppins font-bold text-lg mb-4">Suivez-nous</h3>
            <div className="flex space-x-2">
              {/* FIX: Passed icon components as children to SocialIcon to fix missing 'children' prop error. */}
              <SocialIcon href="https://www.facebook.com/IFMadagascar/">
                  <FacebookIcon/>
              </SocialIcon>
              <SocialIcon href="https://www.instagram.com/ifmadagascar/">
                  <InstagramIcon/>
              </SocialIcon>
              <SocialIcon href="https://www.youtube.com/user/IFMadagascar">
                  <YoutubeIcon/>
              </SocialIcon>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
          <p>Design proposé par Angelo RAKOTONIRINA</p>
          <p>&copy; {new Date().getFullYear()} Institut Français de Madagascar. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
