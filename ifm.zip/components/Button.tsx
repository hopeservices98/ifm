import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ children, onClick, className = '' }) => {
  return (
    <button
      onClick={onClick}
      className={`bg-red-vif text-white font-poppins font-medium text-base px-8 py-3 rounded-lg shadow-md hover:bg-red-vif-hover hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;